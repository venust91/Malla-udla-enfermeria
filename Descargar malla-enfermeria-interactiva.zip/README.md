
# Malla Enfermería UDLA Interactiva

Una malla académica interactiva para Enfermería UDLA (versión rosado pastel + baby blue).

## Cómo usar

1. Abre el archivo `index.html` en tu navegador.
2. Haz clic en un ramo para marcarlo como aprobado.
3. Al aprobar un ramo, se desbloquea el siguiente.

## Créditos

Diseñada por VenusT91, con apoyo de ChatGPT.
